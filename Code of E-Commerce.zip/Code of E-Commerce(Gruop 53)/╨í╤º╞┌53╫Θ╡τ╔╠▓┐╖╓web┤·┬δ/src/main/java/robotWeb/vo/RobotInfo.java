package robotWeb.vo;

public class RobotInfo {
	private String robotid;
	private String robotname;
	private String password;
	private String comfirmpassword;
	private String robotspeed;
	private String picture;
	private String maze;
	
	public String getRobotid() {
		return robotid;
	}
	public void setRobotid(String robotid) {
		this.robotid = robotid;
	}
	public String getRobotname() {
		return robotname;
	}
	public void setRobotname(String robotname) {
		this.robotname = robotname;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getComfirmpassword() {
		return comfirmpassword;
	}
	public void setComfirmpassword(String comfirmpassword) {
		this.comfirmpassword = comfirmpassword;
	}
	public String getRobotspeed() {
		return robotspeed;
	}
	public void setRobotspeed(String robotspeed) {
		this.robotspeed = robotspeed;
	}
	public String getPicture() {
		return picture;
	}
	public void setPicture(String picture) {
		this.picture = picture;
	}
	public String getMaze() {
		return maze;
	}
	public void setMaze(String maze) {
		this.maze = maze;
	}
	
	
}
