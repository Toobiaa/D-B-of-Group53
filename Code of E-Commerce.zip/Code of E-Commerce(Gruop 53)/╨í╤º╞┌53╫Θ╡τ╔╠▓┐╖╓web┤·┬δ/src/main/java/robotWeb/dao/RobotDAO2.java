package robotWeb.dao;

import robotWeb.vo.RobotInfo;

public interface RobotDAO2 {
	public RobotInfo queryByUserInfo (RobotInfo robotinfo) throws Exception;


	
}
