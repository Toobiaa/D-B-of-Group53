package robotWeb.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import robotWeb.dao.RobotDAO2;
import robotWeb.db.DBConnect;
import robotWeb.vo.RobotInfo;

public class RobotImplRecord implements RobotDAO2{
	public RobotInfo queryByUserInfo(RobotInfo robotinfo) throws Exception{
		
		String sql ="select * from robot where robotname=?";
		PreparedStatement pstmt=null;
		DBConnect dbc=null;
		RobotInfo robotInfo = new RobotInfo();
     try {
			
			dbc =new DBConnect();
			pstmt =dbc.getConnection().prepareStatement(sql);
			//pstmt.setString(1, robotinfo.getRobotid());
			pstmt.setString(1, robotinfo.getRobotname());
			ResultSet rs=pstmt.executeQuery();
			while(rs.next()) {
				
				robotInfo.setRobotid(rs.getString("robotid"));
				robotInfo.setRobotname(rs.getString("robotname"));
				robotInfo.setPassword(rs.getString("password"));
				robotInfo.setRobotspeed(rs.getString("robotspeed"));
			    robotInfo.setPicture(rs.getString("picture"));
				robotinfo.setMaze(rs.getString("maze"));
			}
			
			rs.close();
			pstmt.close();
        }catch(SQLException e) {
			System.out.println(e.getMessage());
		}finally {
			dbc.close();
		}
		return robotInfo;
			
	
		
	}
	

	
	
}
