package robotWeb.dao;

import robotWeb.vo.RobotInfo;

public interface RobotDAO {
	 public int queryByUserInfo (RobotInfo robotinfo) throws Exception;
	 
}
