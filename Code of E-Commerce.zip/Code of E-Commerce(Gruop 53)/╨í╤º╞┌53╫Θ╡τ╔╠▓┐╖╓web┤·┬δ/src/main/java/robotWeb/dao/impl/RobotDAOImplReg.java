package robotWeb.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import robotWeb.dao.RobotDAO;
import robotWeb.db.DBConnect;
import robotWeb.vo.RobotInfo;

public class RobotDAOImplReg implements RobotDAO{
	public int queryByUserInfo(RobotInfo robotinfo) throws Exception{
		int flag=0;
		String sql ="insert into robot(robotid,robotname,password,robotspeed) value(?,?,?,?)";
		PreparedStatement pstmt=null;
		DBConnect dbc=null;
		try {
			dbc =new DBConnect();
			pstmt =dbc.getConnection().prepareStatement(sql);
			pstmt.setString(1, robotinfo.getRobotid());
			pstmt.setString(2, robotinfo.getRobotname());
			pstmt.setString(3, robotinfo.getPassword());
			pstmt.setString(4, robotinfo.getRobotspeed());
			pstmt.executeUpdate();
			pstmt.close();
			flag=1;
		}catch(SQLException e) {
			System.out.println(e.getMessage());
		}finally {
			dbc.close();
		}
		return flag;
	}
		 //判断用户名是否存在的方法
		public static boolean Exist(RobotInfo robotinfo) {
			String sql="select robotname from robot where robotname=?";
			PreparedStatement pstmt=null;
			DBConnect dbc=null;
			try {
				dbc =new DBConnect();
				pstmt =dbc.getConnection().prepareStatement(sql);
				pstmt.setString(1, robotinfo.getRobotname());
				ResultSet rs=pstmt.executeQuery();
				return rs.next();
				
			}catch(SQLException e) {
				System.out.println(e);
				return false;
			}finally {
				dbc.close();
			}
		
		
		
	}
	
	  
}
