package robotWeb.dao.impl;
import java.sql.ResultSet;
import java.sql.SQLException;
import robotWeb.dao.RobotDAO;
import java.sql.PreparedStatement;

import robotWeb.db.DBConnect;
import robotWeb.vo.RobotInfo;

public class RobotDAOImpl implements RobotDAO{
	public int queryByUserInfo(RobotInfo robotinfo) throws Exception{
		int flag=0;
		String sql ="select * from robot where robotname=?";
		PreparedStatement pstmt=null;
		DBConnect dbc=null;
		try {
			dbc =new DBConnect();
			pstmt =dbc.getConnection().prepareStatement(sql);
			pstmt.setString(1, robotinfo.getRobotname());
			ResultSet rs=pstmt.executeQuery();
			while(rs.next()) {
				if(rs.getString("password").equals(robotinfo.getPassword())) {
					flag=1;
				}
			}
			rs.close();
			pstmt.close();
		}catch(SQLException e) {
			System.out.println(e.getMessage());
		}finally {
			dbc.close();
		}
		return flag;
	}
	
}
