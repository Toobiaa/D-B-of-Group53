package robotWeb.dao.impl;

import java.sql.PreparedStatement;

import java.sql.SQLException;

import robotWeb.dao.RobotDAO;
import robotWeb.db.DBConnect;
import robotWeb.vo.RobotInfo;

public class RobotImplModify implements RobotDAO{
	public int queryByUserInfo(RobotInfo robotinfo) throws Exception{
		int flag=0;
		String sql ="update robot set robotname=?,password=?,robotspeed=? where robotid=? ";
		PreparedStatement pstmt=null;
		DBConnect dbc=null;
		try {
			dbc =new DBConnect();
			pstmt =dbc.getConnection().prepareStatement(sql);
			
			pstmt.setString(1, robotinfo.getRobotname());
			pstmt.setString(2, robotinfo.getPassword());
			pstmt.setString(3, robotinfo.getRobotspeed());
			pstmt.setString(4, robotinfo.getRobotid());
			
			pstmt.executeUpdate();
			pstmt.close();
			flag=1;
		}catch(SQLException e) {
			System.out.println(e.getMessage());
		}finally {
			dbc.close();
		}
		return flag;
	}
}