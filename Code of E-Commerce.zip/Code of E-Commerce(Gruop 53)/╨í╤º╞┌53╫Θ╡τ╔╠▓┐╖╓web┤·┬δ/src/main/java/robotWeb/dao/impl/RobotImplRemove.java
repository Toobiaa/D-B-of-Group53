package robotWeb.dao.impl;

import java.sql.PreparedStatement;

import java.sql.SQLException;

import robotWeb.dao.RobotDAO2;
import robotWeb.db.DBConnect;
import robotWeb.vo.RobotInfo;

public class RobotImplRemove implements RobotDAO2{
	public RobotInfo queryByUserInfo(RobotInfo robotinfo) throws Exception{
	
		String sql ="delete from robot where robotname=?";
		PreparedStatement pstmt=null;
		DBConnect dbc=null;
		RobotInfo robotInfo = new RobotInfo();
		try {
			dbc =new DBConnect();
			pstmt =dbc.getConnection().prepareStatement(sql);
			pstmt.setString(1, robotinfo.getRobotname());
			
			pstmt.executeUpdate();
			pstmt.close();
		
		}catch(SQLException e) {
			System.out.println(e.getMessage());
		}finally {
			dbc.close();
		}
		return robotInfo;
	}
}
