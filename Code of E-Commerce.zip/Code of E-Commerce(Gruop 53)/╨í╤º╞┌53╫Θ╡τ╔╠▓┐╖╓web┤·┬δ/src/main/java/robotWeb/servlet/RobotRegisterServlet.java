package robotWeb.servlet;
import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import robotWeb.vo.*;
import robotWeb.dao.RobotDAO;
import robotWeb.dao.impl.*;
import robotWeb.db.DBConnect;

public class RobotRegisterServlet extends HttpServlet {
	public void doPost(HttpServletRequest req, HttpServletResponse res)
	    throws IOException,ServletException{
		RobotInfo robotinfo=new RobotInfo();
		robotinfo.setRobotid(req.getParameter("robotid"));
		robotinfo.setRobotname(req.getParameter("robotname"));
		robotinfo.setPassword(req.getParameter("password"));
		robotinfo.setComfirmpassword(req.getParameter("comfirmpassword"));
		robotinfo.setRobotspeed(req.getParameter("robotspeed"));
		RobotDAO dao=new RobotDAOImplReg();
		//判断两次密码是否一致
		if(robotinfo.getPassword().equals(robotinfo.getComfirmpassword())) {
		  //判断用户名是否已经存在
			if(!RobotDAOImplReg.Exist(robotinfo)) {
			int flag=0;
		try {
			flag=dao.queryByUserInfo(robotinfo);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		if(flag==1) {
			HttpSession session=req.getSession();
			session.setAttribute("robotname", robotinfo.getRobotname());
			res.sendRedirect("./welcome.jsp");
		}else {
			res.sendRedirect("./error.jsp");
		}	
		}
			//提示用户名已经存在
			else {
			res.getWriter().write("The robotname already exist.");
		}
		}
		//两次输入的密码不一致
		else {
			res.getWriter().write("The two passwords are different");
		}
		
		
	}
		
	}
	 
	
	
