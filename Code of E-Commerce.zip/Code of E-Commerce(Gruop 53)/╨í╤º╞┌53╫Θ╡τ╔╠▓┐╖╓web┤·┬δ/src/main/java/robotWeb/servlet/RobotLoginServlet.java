package robotWeb.servlet;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import robotWeb.vo.*;
import robotWeb.dao.RobotDAO;
import robotWeb.dao.impl.*;

public class RobotLoginServlet extends HttpServlet {
	public void doPost(HttpServletRequest req, HttpServletResponse res)
	    throws IOException,ServletException{
		RobotInfo robotinfo=new RobotInfo();
		robotinfo.setRobotname(req.getParameter("robotname"));
		robotinfo.setPassword(req.getParameter("password"));
		RobotDAO dao=new RobotDAOImpl();
		int flag=0;
		try {
			flag=dao.queryByUserInfo(robotinfo);
		}	
		catch (Exception e) {
			e.printStackTrace();
		}
		if(flag==1) {
			HttpSession session=req.getSession();
			session.setAttribute("robotname", robotinfo.getRobotname());
			res.sendRedirect("./welcome.jsp");
		}else {
			res.sendRedirect("./error.jsp");
		}
	}
}