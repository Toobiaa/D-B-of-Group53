package robotWeb.servlet;
import java.io.IOException;
import java.io.OutputStream;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import robotWeb.vo.*;
import robotWeb.dao.RobotDAO2;
import robotWeb.dao.impl.*;

public class RobotDeleteServlet extends HttpServlet {
	public void doGet(HttpServletRequest req, HttpServletResponse res)
	    throws IOException,ServletException{
		
		
		try {
			
			RobotDAO2 dao= new RobotlmplDelete();
			
			HttpSession session=req.getSession();
			RobotInfo robot = new RobotInfo();
			
			robot.setRobotname((String)session.getAttribute("robotname"));
			RobotInfo robotinfo = dao.queryByUserInfo(robot);
			
	
		
			session.setAttribute("robotid", robotinfo.getRobotid());
			session.setAttribute("robotname", robotinfo.getRobotname());
			session.setAttribute("password", robotinfo.getPassword());
			session.setAttribute("robotspeed", robotinfo.getRobotspeed());
			session.setAttribute("picture", robotinfo.getPicture());
			res.sendRedirect("./delete.jsp");
			
	
		}
		catch (Exception e) {
			e.printStackTrace();
		}
			
		}
		
	
}
