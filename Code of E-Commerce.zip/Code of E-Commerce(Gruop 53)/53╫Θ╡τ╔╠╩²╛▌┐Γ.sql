-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: localhost    Database: robotdb
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `explore`
--

DROP TABLE IF EXISTS `explore`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `explore` (
  `exploreid` varchar(45) NOT NULL,
  `starttime` varchar(45) DEFAULT NULL,
  `endtime` varchar(45) DEFAULT NULL,
  `spenttime` varchar(45) DEFAULT NULL,
  `maze` varchar(45) DEFAULT NULL,
  `robotid` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`exploreid`),
  KEY `robotid_idx` (`robotid`),
  CONSTRAINT `robotid` FOREIGN KEY (`robotid`) REFERENCES `robot` (`robotid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `explore`
--

LOCK TABLES `explore` WRITE;
/*!40000 ALTER TABLE `explore` DISABLE KEYS */;
INSERT INTO `explore` VALUES ('1','2023.6.30.9:03:20','2023.6.30.9:05:53','2:33',NULL,'1');
/*!40000 ALTER TABLE `explore` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maze`
--

DROP TABLE IF EXISTS `maze`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `maze` (
  `mazeid` varchar(45) NOT NULL,
  `mazetype` varchar(45) DEFAULT NULL,
  `mazeroad` varchar(45) DEFAULT NULL,
  `mazesize` varchar(45) DEFAULT NULL,
  `mazepicture` varchar(45) DEFAULT NULL,
  `exploreid` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`mazeid`),
  KEY `exploreid_idx` (`exploreid`),
  CONSTRAINT `exploreid` FOREIGN KEY (`exploreid`) REFERENCES `explore` (`exploreid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maze`
--

LOCK TABLES `maze` WRITE;
/*!40000 ALTER TABLE `maze` DISABLE KEYS */;
/*!40000 ALTER TABLE `maze` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `monitor`
--

DROP TABLE IF EXISTS `monitor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `monitor` (
  `monitorid` varchar(45) NOT NULL,
  `age` varchar(45) DEFAULT NULL,
  `monitorname` varchar(45) DEFAULT NULL,
  `controlnumber` varchar(45) DEFAULT NULL,
  `m robotid` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`monitorid`),
  KEY `robotid_idx` (`m robotid`),
  CONSTRAINT `m robotid` FOREIGN KEY (`m robotid`) REFERENCES `robot` (`robotid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `monitor`
--

LOCK TABLES `monitor` WRITE;
/*!40000 ALTER TABLE `monitor` DISABLE KEYS */;
/*!40000 ALTER TABLE `monitor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `robot`
--

DROP TABLE IF EXISTS `robot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `robot` (
  `robotid` varchar(45) NOT NULL,
  `robotname` varchar(45) DEFAULT NULL,
  `password` varchar(45) DEFAULT NULL,
  `robotspeed` varchar(45) DEFAULT NULL,
  `picture` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`robotid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `robot`
--

LOCK TABLES `robot` WRITE;
/*!40000 ALTER TABLE `robot` DISABLE KEYS */;
INSERT INTO `robot` VALUES ('1','monster','123','3',''),('2','yeah','5','5',''),('3','xyz','2','3',NULL),('4','53','53','53',NULL),('53','best','111','7',NULL);
/*!40000 ALTER TABLE `robot` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-10-15 20:14:51
