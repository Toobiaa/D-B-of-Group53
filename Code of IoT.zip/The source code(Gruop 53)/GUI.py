import tkinter as tk
from PIL import Image, ImageTk
import os

# 创建一个Tkinter窗口
root = tk.Tk()
root.title("展示图片")

# 设置窗口的宽度和高度
window_width = 1400  # 设置窗口宽度
window_height = 1000  # 设置窗口高度
root.geometry(f"{window_width}x{window_height}")

# 获取两个图片文件夹的路径
image_folder1 = r"D:\01"  # 替换为第一个图片文件夹的路径
image_folder2 = r"D:\mini-semester\yolov8_new\runs\detect\predict35"  # 替换为第二个图片文件夹的路径
image_paths1 = []
image_paths2 = []

# 列出第一个文件夹中的所有图片文件
for filename in os.listdir(image_folder1):
    if filename.endswith((".png", ".jpg", ".jpeg", ".gif")):
        image_paths1.append(os.path.join(image_folder1, filename))

# 列出第二个文件夹中的所有图片文件
for filename in os.listdir(image_folder2):
    if filename.endswith((".png", ".jpg", ".jpeg", ".gif")):
        image_paths2.append(os.path.join(image_folder2, filename))

# 获取两个文件夹中文件名完全相同的图片路径
common_image_paths = [path for path in image_paths1 if os.path.basename(path) in [os.path.basename(path2) for path2 in image_paths2]]

current_image_index = 0  # 当前显示的图片索引

# 创建一个函数，用于切换图片
def change_image():
    global current_image_index
    # 循环切换图片索引
    current_image_index = (current_image_index + 1) % len(common_image_paths)
    # 加载新的图片
    new_image1 = Image.open(common_image_paths[current_image_index])
    new_photo1 = ImageTk.PhotoImage(new_image1)
    # 更新左侧标签中的图片
    label1.config(image=new_photo1)
    label1.photo = new_photo1  # 防止被垃圾回收
    # 加载新的右侧图片
    new_image2 = Image.open(image_paths2[current_image_index])
    new_photo2 = ImageTk.PhotoImage(new_image2)
    label2.config(image=new_photo2)
    label2.photo = new_photo2  # 防止被垃圾回收

# 将第一张共同图片转换为Tkinter PhotoImage对象
if common_image_paths:
    initial_image = Image.open(common_image_paths[0])
    initial_photo = ImageTk.PhotoImage(initial_image)

    # 创建一个标签来展示图片（左侧）
    label1 = tk.Label(root, image=initial_photo)
    label1.grid(row=0, column=0, padx=10, pady=10)

    # 创建一个文本标签来显示文字
    text1 = "Original Picture"
    text_label1 = tk.Label(root, text=text1, font=("Arial", 16))
    text_label1.grid(row=1, column=0, padx=10, pady=10)

    # 创建一个标签来展示`photo2`文件夹中的图片（右侧）
    initial_image2 = Image.open(image_paths2[0])
    initial_photo2 = ImageTk.PhotoImage(initial_image2)
    label2 = tk.Label(root, image=initial_photo2)
    label2.grid(row=0, column=1, padx=10, pady=10)

    # 创建一个文本标签来显示文字
    text2 = "Outcome"
    text_label2 = tk.Label(root, text=text2, font=("Arial", 16))
    text_label2.grid(row=1, column=1, padx=10, pady=10)

    # 创建一个按钮来切换图片
    button = tk.Button(root, text="Change image", command=change_image)
    button.grid(row=2, column=0, columnspan=2, padx=10, pady=10)

# 启动Tkinter事件循环
root.mainloop()