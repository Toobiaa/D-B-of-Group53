# treasure detect > 2023-06-26 2:18pm
https://universe.roboflow.com/test-8jfjf/treasure-detect

Provided by a Roboflow user
License: CC BY 4.0

