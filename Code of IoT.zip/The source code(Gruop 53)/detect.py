from ultralytics import YOLO
import os

model = YOLO('best.pt')
#img_path = "./testImage/"
img_path = r"D:\01" 
results = model.predict(img_path, save=True, save_txt=True, conf=0.6) # device=0 by default, conf:置信度阈值

###############################删除未被识别的图片#############################################################################################
#predict文件夹里面有图片和labels文件夹
#图片里没有“宝藏”，labels里就没有对应的txt文件
#思路：删去没有对应txt文件的图片
def delete_files_not_in_a(a_folder, b_folder):
    # 获取a文件夹中的所有txt文件的名称
    a_files = set([f[:-4] for f in os.listdir(a_folder) if f.endswith('.txt')])

    # 获取b文件夹中的所有jpg文件
    b_files = [f for f in os.listdir(b_folder) if f.endswith('.jpg')]

    # 遍历b文件夹中的文件，如果文件名不在a文件夹中，则删除
    for b_file in b_files:
        file_name_without_extension = b_file[:-4]
        if file_name_without_extension not in a_files:
            file_path = os.path.join(b_folder, b_file)
            os.remove(file_path)
            print(f"Deleted: {file_path}")

# 指定a文件夹和b文件夹的路径
a_folder_path = r'D:\mini-semester\yolov8_new\runs\detect\predict35\labels'
b_folder_path = r'D:\mini-semester\yolov8_new\runs\detect\predict35'

# 调用函数删除不在a文件夹中的文件
delete_files_not_in_a(a_folder_path, b_folder_path)